INSERT INTO project_manager(id, name, username, password, project_name) VALUES (1, 'Raj Shi', 'raj', 'raj12', 'Project-1');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (2, 'Jimmy Fallon', 'jimmy', 'jimmy12', 'Project-2');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (3, 'Kim Taehyung', 'kim', 'kim12', 'Project-3');
INSERT INTO project_manager(id, name, username, password, project_name) VALUES (4, 'Allan charles', 'allen', 'allen12', 'Project-4');
